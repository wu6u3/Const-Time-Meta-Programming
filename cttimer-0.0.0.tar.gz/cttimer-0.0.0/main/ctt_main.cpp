#include<iostream>

#include"ctt_timer.hpp"



using namespace CTTimer;
int main(){

//  double su = sum(1.3,2.3,3.6,4.6,56.4,7623.4,7.2);
  std::cout<<sum(1.3,2.3,3.6,4.6,56.4,7623.4,7.2)<<std::endl;
//  std::cout<<fold_mul_1(1.3,2.3,3.6,4.6,56.4,7623.4,7.2)<<std::endl;

}
