#include"ctt_utility.hpp"

namespace CTTimer{

int sum_non(int a, int b){
  return a+b;
}

};

