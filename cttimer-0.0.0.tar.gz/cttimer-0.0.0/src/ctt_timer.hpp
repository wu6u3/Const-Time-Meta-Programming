#ifndef __CTTimer__
#define __CTTimer__

#include<iostream>
#include "ctt_utility.hpp"

namespace CTTimer{

};

#endif
