#ifndef __CTT_UTILITY__
#define __CTT_UTILITY__


#include<iostream>
namespace CTTimer{

template<typename... T>
static constexpr auto sum(T... s){
  return (...+s);
}


template<typename... T>
void print_arrays(T&&... arrays){
  (std::cout << ... <<arrays) << '\n';
}


int sum_non(int a, int b);
};

#endif
